# Text animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/mileswolfallen2-the-typescripter/pen/VwdGgJL](https://codepen.io/mileswolfallen2-the-typescripter/pen/VwdGgJL).

Text animation by Yoann HELIN 