module.exports = {
  "extends": "angular"
};
