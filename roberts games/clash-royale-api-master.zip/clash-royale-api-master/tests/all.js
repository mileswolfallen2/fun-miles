require('./auth.spec');
require('./cards.spec');
require('./leagues.spec');
require('./arenas.spec');
require('./chests.spec');
require('./players.spec');
require('./main.spec');
require('./cms.spec');
