module.exports = {
  "extends": "airbnb"
};
