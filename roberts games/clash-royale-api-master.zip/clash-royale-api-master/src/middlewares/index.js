module.exports = require('../libraries/requiere-all')(__dirname, {
  stripFromName: '-middleware',
});
