**********
*ROM info*
**********
Format: N64 ROM (big-endian)
Database match: Legend of Zelda, The - Ocarina of Time (USA)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: AD69C91157F6705E8AB06C79FE08AAD47BB57BA7
File/ROM CRC32: CD16C529


*************
*How to play*
*************
Patches has been currently updated and Tested, Working perfectly on Retroarch Emulator (Mupen Core),Project 64 3.0.1 & WiiVC
 
NOTE - Use (Rom patcher Js) to patch 

1) To play on Emulator use (Time Lost N64 1.02.bps) and patch it over "Legend of Zelda - Ocarina of Time (USA 1.0)"

2) To play on wii console/wiiVC use ( Time Lost WiiVC 1.02.bps) and patch it over "The Legend of Zelda - Ocarina of Time.wad"

Have Fun!