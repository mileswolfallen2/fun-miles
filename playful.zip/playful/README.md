# Playful

A Pen created on CodePen.io. Original URL: [https://codepen.io/mileswolfallen2-the-typescripter/pen/dyaLExe](https://codepen.io/mileswolfallen2-the-typescripter/pen/dyaLExe).

Inspired by Nordstrom Rack's brand promo by jkrGlobal (https://jkrglobal.com/): https://twitter.com/offgrid_design/status/1725770853777084578