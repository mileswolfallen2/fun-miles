# tecmogeek.com

Source code for tecmogeek.com, my little fan site for the classic NES game, Tecmo Super Bowl.

Site is built using Jekyll, with help from Sass and Bourbon. I using the jsonball plugin by Alex Heneveld to parse player and team data and present it on the pages.

Start the Jekyll server and watch the Sass/Bourbon files with:

    rake server

