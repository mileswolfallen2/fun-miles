# A Browser Snake Game Built With Vanilla ~~JS~~ Python!

### More details: [Sick Of JavaScript For The Web? Just Write Browser Python Instead](https://medium.com/@yakko.majuri/sick-of-javascript-just-use-browser-python-4b9679efe08b?source=friends_link&sk=40e664d45bfea34d35189c32cd5d0a51)

Want to improve the game? Feel free to submit a pull request!
