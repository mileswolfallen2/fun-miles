# Blades in the Dark System Reference Document

This is the text version of the content found at https://bladesinthedark.com/. The text is available as both Markdown and HTML.

## Licensing

This work is based on Blades in the Dark (found at http://www.bladesinthedark.com/), product of One Seven Design, developed and authored by John Harper, and licensed for our use under the [Creative Commons Attribution 3.0 Unported license](http://creativecommons.org/licenses/by/3.0/).
