window.parent.maeExportApis_();
console.log("This game is from 3kh0.github.io! Yes the mulitplayer is fake, it is just bots.")