How to run the project. 

Way 1: Executable

1. Navigate to the folder /ImpossibleQuize/Builds
2. Run the precompiled ImpossibleQuiz.exe
3. Enjoy!

Note: This game hasn't been optimized for all screen sized, so some slight graphical issues may occur depending on the screen that you are playing on.

Way 2: Unity Game Engine

1. Download Unity Game Engine 2020.2.4f1 from Unity.com
2. Open /ImpossibleQuiz folder with Unity Game Engine
3. You will now have simple access to all the files.

Note: If you don't want to download Unity, all the files that we worked on are located in /ImpossibleQuiz/Assets. Here you can find our source code in 'scripts' and our sprites, etc. in their respective folders.

Thanks!