import pgzrun
import random
FONT_COLOR = (255, 255, 255) #màu RGB
WIDTH = 1300
HEIGHT = 700
CENTER_X = WIDTH / 2
CENTER_Y = HEIGHT / 2
CENTER = (CENTER_X, CENTER_Y)
def draw():
    screen.clear()
    screen.blit("dark",(0,0))

def update():
    pass

def make_impostors(number_of_impostors):
    pass

def get_colors_to_create(number_of_impostors):
    pass

def create_impostors(colors_to_create):
    pass

def layout_impostors(impostors_to_layout):
    pass

def animate_impostors(impostors_to_animate):
    pass

def handle_game_over():
    pass

def on_mouse_down(pos):
    pass

def red_impostor_click():
   pass

def stop_animations(animations_to_stop):
    pass

def display_message(heading_text, sub_heading_text):
    pass

pgzrun.go()
