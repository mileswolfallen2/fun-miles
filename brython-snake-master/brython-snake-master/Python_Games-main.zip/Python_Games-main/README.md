# Python_Games

- [1. Fruit Shooter Game](./1_Fruit_Shooter)
- [2. Mario Bounty Hunter](./2_Mario_Bounty_Hunter)
- [3. Google Translate](./3_Google_Translate)
- [4. Among Us](./4_Among_Us)
- [5. Flappy Bird](./5_Flappy_Bird)
