# Dungeon Crawler

<a href='https://jbarajar.github.io/DungeonCrawler/'> <h2>Play Here</h2></a>

<img src='https://github.com/JBarajar/DungeonCrawler/blob/master/screenshots/screenshot1.png' width='400'> <img src='https://github.com/JBarajar/DungeonCrawler/blob/master/screenshots/screenshot2.png' width='400'>

2D Zelda-style dungeon crawler game built using Javascript and Canvas.

<h4>Controls:</h4>
<p>Move: WSAD<br/>
Attack: Spacebar</p>
